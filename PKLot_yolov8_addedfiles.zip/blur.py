import json
import cv2
import numpy

from ultralytics import YOLO

img = cv2.imread("C:/Users/gmrut/PycharmProjects/PKLot_yolov8/runs/detect/predict/2012-09-13_13_25_24_jpg.rf.fd17435c075567f752d1aeb5dc085e3f.jpg")

with open('data.json', "r") as json_file:
    data = json.load(json_file)

for obj in data:
    blur_x = int((obj[3][0] + obj[3][2]) / 2)
    blur_y = int((obj[3][1] + obj[3][3]) / 2)
    blur_width = int(obj[3][2] - obj[3][0])
    blur_height = int(obj[3][3] - obj[3][1])


    roi = img[blur_y:blur_y + blur_height, blur_x:blur_x + blur_width]
    blur_image = cv2.GaussianBlur(roi, (51, 51), 0)

    img[blur_y:blur_y + blur_height, blur_x:blur_x + blur_width] = blur_image

    cv2.imwrite("example_with_blur.jpg", img)